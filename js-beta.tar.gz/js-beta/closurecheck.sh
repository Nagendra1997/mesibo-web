java -jar /home/mesibo/closure-compiler-v20191111.jar --compilation_level ADVANCED_OPTIMIZATIONS --js scripts/*

